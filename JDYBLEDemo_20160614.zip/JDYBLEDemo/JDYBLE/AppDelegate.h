//
//  AppDelegate.h
//  JDYBLE
//
//  Created by zqf on 16/6/12.
//  Copyright © 2016年 zengqingfu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

